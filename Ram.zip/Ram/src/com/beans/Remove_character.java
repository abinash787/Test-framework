package com.beans;

public class Remove_character {

	public static void main(String[] args) {
		String s="!@#j^i$t*u";
		String s1=s.replaceAll("[^a-zA-Z]", "");
		System.out.println(s1);
		
	}

}
